#!/bin/bash

# SBATCH -N 1
# SBATCH --time=72:00:00

/home/gchennupati/Applications/performance_prediction_toolkit/scripts/run_polybench_generic_2015_10_28/runtime.sh 2mm

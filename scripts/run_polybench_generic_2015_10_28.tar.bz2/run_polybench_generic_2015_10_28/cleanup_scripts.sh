#!/bin/bash
# EJ Park
# ejpark@lanl.gov
# Last modified: Oct 28, 2015
# To clean up generated scripts using gen_script_*.sh
#####################################################

rm -rf runtime_*.sh runpapi_*.sh
